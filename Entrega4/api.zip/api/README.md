### Funcionamiento general:

Básicamente se hicieron las consultas en función al archivo de prueba que fue entregado para testear las consultas.
Por lor que se puede guiar de ese archivo para revisar nuestro trabajo (Aunque asumo que se utilizará el mismo
formato para corregir).
Más abajo haré algunas aclaraciones, pero a grandes rasgos, basta con lo que se acaba de indicar.


### POST:

Se tiene que utilizar la siguiente url, con el método POST:
http://localhost:5000/messages

Y se tienen que introducir en el body json de la siguiente forma:

{"date": "2020-06-12",
"lat": -42.24,
"long": -3243
"message": "hola hola hola",
"receptant": 2
"sender": 3}

no se debe incluir un "mid" puesto que se asigna solo si el mensaje se crea exitosamente.


### DELETE

Se tiene que utilizar la siguiente url, con el método DELETE:
http://localhost:5000/message/:id

En donde simplemente se debe poner el id deseado en la url para borrar el mensaje.
No requiere ningún tipo de body.